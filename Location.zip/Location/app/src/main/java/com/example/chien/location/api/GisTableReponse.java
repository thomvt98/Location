package com.example.chien.location.api;

public class GisTableReponse extends BaseRepose {

}
