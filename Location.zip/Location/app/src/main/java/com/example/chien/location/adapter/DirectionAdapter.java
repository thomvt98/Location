package com.example.chien.location.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.chien.location.model.NodeGis;
import com.example.chien.location.R;

import java.util.ArrayList;

public class DirectionAdapter extends BaseAdapter {
    int resource;
    Context context;
    ArrayList<NodeGis> coorList;

    public DirectionAdapter(int resource, Context context, ArrayList<NodeGis> coorList) {
        this.resource = resource;
        this.context = context;
        this.coorList = coorList;
    }

    @Override
    public int getCount() {
        return coorList.size();
    }

    @Override
    public Object getItem(int position) {
        return coorList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.tvLat = convertView.findViewById(R.id.tvLat);
            viewHolder.tvLng = convertView.findViewById(R.id.tvLng);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        NodeGis coor = (NodeGis) getItem(position);
        viewHolder.tvLat.setText(String.valueOf(coor.getLat()));
        viewHolder.tvLng.setText(String.valueOf(coor.getLng()));

        return convertView;
    }

    public class ViewHolder {
        TextView tvLat, tvLng;
    }
}
