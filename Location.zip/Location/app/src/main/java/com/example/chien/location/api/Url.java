package com.example.chien.location.api;

public class Url {
    public static final String BASEAPP_URL = "http://117.6.131.222:4010/";
}
