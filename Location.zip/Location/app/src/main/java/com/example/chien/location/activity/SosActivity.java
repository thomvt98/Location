package com.example.chien.location.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chien.location.R;
import com.example.chien.location.adapter.SosAdapter;
import com.example.chien.location.model.GisTable;
import com.example.chien.location.model.NodeGis;
import com.example.chien.location.model.SosInfo;
import com.example.chien.location.model.SosMedia;
import com.example.chien.location.sqlite.DatabaseHelper;
import com.example.chien.location.sqlite.DatabaseSos;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SosActivity extends AppCompatActivity {
    private TextView txtSosCode;
    private Button btnSave, btnIntent, btnUpdate;
    private EditText edtTitle, edtNote;
    private RadioButton rdCao, rdThap, rdTrungBinh;
    private ImageView pic1, pic2, pic3;
    private ArrayList<SosInfo> list;
    private SosInfo sosInfo;
    private RadioGroup rdGroup;
    private String priority;
    private static final int PICK_IMAGE = 14;
    private static final int REQUEST_PHOTO = 3;
    private static final int MY_CAMERA_REQUEST_CODE = 2;
    DatabaseSos db;
    private int selected;
    private Uri contentURI;
    private String uri1,uri2,uri3;
    private SosMedia sosMedia;
    SosAdapter sosAdapter;
    public static final String DATA = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz|!£$%&/=@#";
    public static Random RANDOM = new Random();

    public static String randomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            sb.append(DATA.charAt(RANDOM.nextInt(DATA.length())));
        }
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sos);
        init();
        eventsButton();
        Reciver();

    }

    private void init() {
        btnSave = findViewById(R.id.btnSave);
        btnIntent = findViewById(R.id.btnIntent);
        txtSosCode = findViewById(R.id.txtSosCode);
        edtTitle = findViewById(R.id.edtTitle);
        edtNote = findViewById(R.id.edtNote);
        rdCao = findViewById(R.id.rdCao);
        rdThap = findViewById(R.id.rdThap);
        rdTrungBinh = findViewById(R.id.rdTrungBinh);
        rdGroup = findViewById(R.id.rdGroup);
        pic1 = findViewById(R.id.pic1);
        pic2 = findViewById(R.id.pic2);
        pic3 = findViewById(R.id.pic3);
        db = new DatabaseSos(this);
        btnUpdate = findViewById(R.id.btnupdate);
    }

    private void eventsButton() {
        pic1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage("You want to choose?");
                builder.setCancelable(false);
                selected = 1;
                builder.setPositiveButton("CAMERA", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, MY_CAMERA_REQUEST_CODE);
                    }
                });
                builder.setNegativeButton("PHOTO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(SosActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PHOTO);
                        } else {
                            Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(galleryIntent, PICK_IMAGE);
                        }
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
        pic2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage("You want to choose?");
                builder.setCancelable(false);
                selected = 2;
                builder.setPositiveButton("CAMERA", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, MY_CAMERA_REQUEST_CODE);
                    }
                });
                builder.setNegativeButton("PHOTO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(SosActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PHOTO);
                        } else {
                            Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(galleryIntent, PICK_IMAGE);
                        }
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }


        });
        pic3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage("You want to choose?");
                builder.setCancelable(false);
                selected = 3;
                builder.setPositiveButton("CAMERA", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, MY_CAMERA_REQUEST_CODE);
                    }
                });
                builder.setNegativeButton("PHOTO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(SosActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PHOTO);
                        } else {
                            Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(galleryIntent, PICK_IMAGE);
                        }
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }


        });


        rdGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                int checkedRadioId = radioGroup.getCheckedRadioButtonId();
                if (checkedRadioId == R.id.rdCao) {
                    priority = "Cao";
                } else if (checkedRadioId == R.id.rdThap) {
                    priority = "Thap";
                } else priority = "Trung Binh";
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String title = edtTitle.getText().toString();
                String note = edtNote.getText().toString();
                String soscode = txtSosCode.getText().toString();
                sosInfo = new SosInfo(title, note, soscode, priority);
                String filepath=uri1+", "+uri2+", "+uri3;
                sosInfo = new SosInfo(title, note, soscode, priority);
                sosMedia = new SosMedia(soscode, filepath);

                // Add data into to Sqlite
                db.addData(sosInfo);
                sosInfo.setSos_title(title);
                sosInfo.setSos_note(note);
                sosInfo.setSos_code(soscode);
                sosInfo.setPriority(priority);

                db.addSOSMedia(sosMedia);
                sosMedia.setSos_code(soscode);
                sosMedia.setFile_path(filepath);
            }
        });

        btnIntent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SosListActivity.class);
                startActivity(intent);
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SosListActivity.class);
                sosInfo = (SosInfo) getIntent().getSerializableExtra("ID");
                sosInfo.setSos_code(list.toString());
                sosInfo.setSos_note(list.toString());
                sosInfo.setSos_title(list.toString());
                sosInfo.setPriority(list.toString());
                DatabaseSos db = new DatabaseSos(getApplicationContext());
                db.update(sosInfo);
                Toast.makeText(getApplication(), "Sửa thành công", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                sosAdapter.notifyDataSetChanged();
            }
       });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_IMAGE && data != null) {
            contentURI = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(SosActivity.this.getContentResolver(), contentURI);
                switch (selected) {
                    case 1:
                        pic1.setImageBitmap(bitmap);
                        uri1 = contentURI.toString();
                        break;
                    case 2:
                        pic2.setImageBitmap(bitmap);
                        uri1 = contentURI.toString();
                        break;
                    case 3:
                        pic3.setImageBitmap(bitmap);
                        uri1 = contentURI.toString();
                        break;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            switch (selected) {
                case 1:
                    pic1.setImageBitmap(bitmap);
                  //  contentURI= getImageUri(getApplication(),bitmap);
                    //uri1=contentURI.toString();
                    break;
                case 2:
                    pic2.setImageBitmap(bitmap);
                   // contentURI= getImageUri(SosActivity.this,bitmap);
                 //   uri1=contentURI.toString();
                    break;
                case 3:
                    pic3.setImageBitmap(bitmap);
                    //contentURI= getImageUri(SosActivity.this,bitmap);
                    //uri1=contentURI.toString();
                    break;
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
   


    public void Reciver() {
        sosInfo=(SosInfo) getIntent().getSerializableExtra("ID");
        try {

                String txsos_code = String.valueOf(getIntent().getSerializableExtra("SOS_CODE"));
                txtSosCode.setText(txsos_code);
                txtSosCode.setEnabled(false);
                String txttitle = String.valueOf(getIntent().getSerializableExtra("TITLE"));
                edtTitle.setText(txttitle);
                String txtnote = String.valueOf(getIntent().getSerializableExtra("NOTE"));
                edtNote.setText(txtnote);
                String txtPriority = String.valueOf(getIntent().getSerializableExtra("Priority"));
                if(txtPriority.equals("Trung Binh")){
                    rdTrungBinh.setEnabled(true);
                } else if(txtPriority.equals("Thap")){
                    rdThap.setEnabled(true);
                } else rdCao.setEnabled(true);

        }catch (Exception e)
        {
        }}


    @Override
    protected void onStart() {
        super.onStart();
        txtSosCode.setText(randomString(10));
    }
}
